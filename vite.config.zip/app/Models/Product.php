<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'brand',
        'price',
        'stock',
        'description',
        'skin_type', // Contoh: Berminyak, Kering, Jerawat, Sensitivity
        'image',
    ];
}
